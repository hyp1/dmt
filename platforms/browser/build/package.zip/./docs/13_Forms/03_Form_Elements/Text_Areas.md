Also, checkout the [Text Widget](../../Widgets/Text_Widget) page.

![Text Area Widget](http://drupalgap.com/sites/default/files/textarea-widget.png)

```
form.elements['my_textarea'] = {
  title: 'Phrase',
  type: 'textarea',
  default_value: 'Hello'
};
```